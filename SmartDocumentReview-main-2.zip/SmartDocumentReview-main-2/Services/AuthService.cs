
namespace SmartDocumentReview.Services
{
    public class AuthService
    {
        public string CurrentUser => "testuser";
    }
}
